<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3>Task List</h3>
                    <form action="<?php echo e(route('task.index')); ?>" method="get" class="form-check">
                        <div class="form-group make-inline">
                            
                            <select name="status_id" style="margin:30px;float:left">
                                <option value="0" disabled <?php if($filterBy==0): ?> selected <?php endif; ?>>Select status</option>

                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status->id); ?>" <?php if($filterBy==$status->id): ?> selected <?php endif; ?>> <?php echo e($status->name); ?> </option>
                                <small class="form-text text-muted">your choice, please</small>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group form-check-inline ">
                            <div style="padding:20px;float:left">

                                <label class="form-check">Sort by:</label>

                                <label class="form-check-label" for="sortASC">Name</label>
                                <input type="radio" class="form-check-input" name="sort" value="asc" id="sortASC" <?php if($sortBy=='asc' ): ?> checked <?php endif; ?>>

                                Completed <input type="radio" class="form-check-input" name="sort" value="desc" id="sortDESC" <?php if($sortBy=='desc' ): ?> checked <?php endif; ?>>
                            </div>

                            <div class="list-line__buttons" style="padding:20px;float:left">
                                <button type="submit" class="btn btn-info btn-sm">Sort</button>
                                <a href="<?php echo e(route('task.index')); ?>" class="btn btn-info btn-sm">Clear sort</a>

                            </div>
                    </form>
                </div>

                <div class="card-body">
                    <ul class="list-group">
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item list-line">
                            <div style="padding:10px;float:left">
                                <h3><?php echo e($task->name); ?></h3>
                                <h5><?php echo $task->about; ?></h5> <?php echo e($task->completed); ?><br>
                                Status: <?php echo e($task->taskStatus->name); ?>

                            </div>
                            <div style="padding:15px;float:right">

                                <form method="POST" action="<?php echo e(route('task.destroy', [$task])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">X</button>
                            </div>
                            </form>
                            <div style="padding:15px;float:right">
                                <a href="<?php echo e(route('task.edit',[$task])); ?>" class="btn btn-warning btn-sm">EDIT</a>
                            </div>
                            <div style="padding:15px;float:left">
                                <a href="<?php echo e(route('task.pdf',[$task])); ?>" class="btn btn-primary btn-sm">PDF</a>
                            </div>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="paginator-container">
                        <?php echo e($tasks->links()); ?>


                    </div>



                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Test/test/resources/views/task/index.blade.php ENDPATH**/ ?>