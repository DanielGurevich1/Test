<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">EDIT TASK</div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('task.update', [$task])); ?>">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" name="task_name" value="<?php echo e(old($task->name, $task->name)); ?>">
                            <small class="form-text text-muted">enter task name</small>
                        </div>
                        <div class="form-group">
                            <label>Dead-line</label>
                            <input type="text" class="form-control" name="task_completed" value="<?php echo e(old($task->completed, $task->completed)); ?>">
                            <small class="form-text text-muted">enter task deadline</small>
                        </div>

                        About: <textarea name="task_about" id="summernote"><?php echo e($task->about); ?></textarea>


                        <select name="status_id">
                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-warning btn-sm">EDIT</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $('#summernote').summernote();
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Test/test/resources/views/task/edit.blade.php ENDPATH**/ ?>