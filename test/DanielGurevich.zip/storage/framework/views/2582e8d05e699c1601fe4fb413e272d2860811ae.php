<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">EDIT A TASK</div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('status.update', [$status->id])); ?>">

                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" name="status_name" value="<?php echo e($status->name); ?>">
                            <small class="form-text text-muted">enter status name</small>
                        </div>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-warning btn-sm">EDIT</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Test/test/resources/views/status/edit.blade.php ENDPATH**/ ?>