<h3><?php echo e($task->name); ?></h3>
<h5><?php echo $task->about; ?></h5> <?php echo e($task->completed); ?><br>
Status: <?php echo e($task->taskStatus->name); ?>


<hr>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Test/test/resources/views/task/pdf.blade.php ENDPATH**/ ?>