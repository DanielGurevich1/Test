<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h2 style="padding:15px;float:left;">STATUS LIST</h2>

                    <form action="<?php echo e(route('status.index')); ?>" method="get">
                        
                        <div class="form-group " style="padding:10px;float:right">
                            <button type="submit" class="btn btn-info">Filter</button>
                        </div>
                        <div class="form-group " style="padding:10px;float:right">

                            <input class="form-check-input" type="radio" name="sort" value="asc" <?php if($filterBy=='asc' ): ?> checked <?php endif; ?> id="sortBy">
                            <label class="form-check-label" for="sortBy">name</label>

                        </div>
                        <div class="form-group " style="padding:10px;float:right">
                            <input class="form-check-input" type="radio" name="sort" value="desc" <?php if($filterBy=='asc' ): ?> checked <?php endif; ?> id="sortByDesc">
                            <label class="form-check-label" for="sortByDesc">name</label>
                        </div>
                    </form>
                </div>

                <div class="card-body">
                    <ul class="list-group">
                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item list-line">
                            <div class="form-group" style="padding:10px;float:left">
                                <label>
                                    <h3><?php echo e($status->name); ?></h3>
                                </label>

                            </div>

                            <div style="padding:10px;float:right">
                                <form method="POST" action="<?php echo e(route('status.destroy', [$status])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">DELETE</button>
                                </form>
                                <div style="padding:10px;float:right">
                                    <a href="<?php echo e(route('status.edit',[$status])); ?>" class="btn btn-warning btn-sm">EDIT</a>
                                </div>
                            </div>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Test/test/resources/views/status/index.blade.php ENDPATH**/ ?>