<h3>{{$task->name}}</h3>
<h5>{!!$task->about!!}</h5> {{$task->completed}}<br>
Status: {{$task->taskStatus->name}}

<hr>
